﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace part1_attempt_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // create an instance for class welcome_message for voice greeting
            new welcome_message() { };

            // display the ascii image/logo
            // creating an instance
            new logo_design() { };

            // creating an instance for the class "design_prompt" that holds the design
            new design_prompt() { };

            // create instance for filter class that will filter questions
            new filter() { };
        }
    }
}
