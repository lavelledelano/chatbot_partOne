﻿using System.IO;
using System.Media;
using System;

namespace part1_attempt_4
{
    public class welcome_message
    {
        public welcome_message()
        {
            // getting full location of the project
            string full_location = AppDomain.CurrentDomain.BaseDirectory;

            // replace the bin\debug folder in the full_location
            string new_path = full_location.Replace("bin\\Debug\\", "");

            // try and catch
            try
            {
                string full_path = Path.Combine(new_path, "voice_greeting.wav");

                // now we create an instance for SoundPlay class
                using (SoundPlayer play = new SoundPlayer(full_path))
                {
                    // play the file
                    play.PlaySync();
                } // end of using

            }
            catch (Exception error)
            {
                Console.WriteLine(error.Message);
            } // end of catch
        }
    }
}