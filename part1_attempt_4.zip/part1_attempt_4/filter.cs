﻿using System.Collections;
using System;

namespace part1_attempt_4
{
    public class filter
    {
        private string user_name = string.Empty;
        private string UserQuestions = string.Empty;
        public filter()
        {
            //varaiable declaration and arrays
            ArrayList question = new ArrayList();
            ArrayList ignore = new ArrayList();

            // then store
            question.Add("safe browsing is a security feature, often found in web browsers that helps guard users from dangerous websites and downloads by checking them against lists of known unsafe resources and issuing warnings. "); 
            question.Add("passwords are vital for protecting information and has to be protected at all times. ");
            question.Add("SQL injection (SQLi) is a type of attack that injects malicious SQL code into an application, allowing the attacker to view or modify a database. ");
            question.Add("cybersecurity refers to any technologies, practices and policies for preventing Cyberattacks or mitigating their impact. ");
            question.Add("Phishing/phishing is a type of computer attack that uses fraudulent emails, text messages, phone calls or websites to trick people into sharing sensitive data. ");
            question.Add("A cyberattack (cyberattacks) is any intentional effort to steal, expose, alter, disable, or destroy data. ");
            ignore.Add("please");
            ignore.Add("can");
            ignore.Add("is");
            ignore.Add("a");
            ignore.Add("into");
            ignore.Add("in");
            ignore.Add("an");
            ignore.Add("their");
            ignore.Add("any");
            ignore.Add("has");
            ignore.Add("be");
            ignore.Add("uses");
            ignore.Add("you");
            ignore.Add("for");
            ignore.Add("tell");
            ignore.Add("help");
            ignore.Add("helps");
            ignore.Add("assist");
            ignore.Add("show");
            ignore.Add("me");
            ignore.Add("i");
            ignore.Add("know");
            ignore.Add("something");
            ignore.Add("about");
            ignore.Add("related to");
            ignore.Add("to");
            ignore.Add("me");
            ignore.Add("or");
            ignore.Add("and");
            ignore.Add("about");

            // then prompt the user for the question
            // now the chatbot asks for the username
            Console.WriteLine(); Console.WriteLine(); Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("  ChatBot:- >  ");
            // then set the colour for the question
            Console.ForegroundColor = ConsoleColor.Gray;

            Console.WriteLine(" Please enter your name. ");
            Console.WriteLine("  ____________________________________");
            // this is where the user enters their name
            // change colour before we do the while loop
            // then change the font colour so the user sees their name in a different colour 
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("  You:->  ");
            // then ask the name
            Console.WriteLine(" ");
            user_name = Console.ReadLine();
            string modifiedinput0 = "  " + user_name;
            Console.WriteLine(modifiedinput0);

            // now we recreate the interface
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("  ChatBot:-> ");
            //set a gray colour for the question
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(" Hey " + user_name + " ,how can i help you today? ");
            Console.WriteLine("  ____________________________________");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("  You:->  ");
            string ask = Console.ReadLine();
            string modifiedinput = "  " + ask;
            Console.WriteLine(modifiedinput);

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("  ____________________________________");
            Console.Write("  ChatBot:-> ");
            Console.WriteLine(" ");


            //split the question and store in 1D array
            // variable holding question is ask because it is assigned to what ther user inputs hence ReadLine();
            string[] filtered_q = ask.Split(' ');
            ArrayList correct_filtered = new ArrayList();

            // then display the answer using for loop
            // as it searches it should filter more
            Boolean found = false;

            for (int count = 0; count < filtered_q.Length; count++)
            {
                // then we use final filter
                if (!ignore.Contains(filtered_q[count]))
                {
                    // then assign to true
                    found = true;
                    // then add the value to correct flitered
                    correct_filtered.Add(filtered_q[count]);

                }

            }
            // then check if found
            if (found)
            {
                // then loop to show the answers
                for (int counting = 0; counting < correct_filtered.Count; counting++)
                {

                    // then display the answer
                    for (int count = 0; count < question.Count; count++)
                    {
                        // then finally display the found one 
                        if (question[count].ToString().Contains(correct_filtered[counting].ToString()))
                        {


                            // ouput
                            Console.WriteLine(question[count].ToString());
                            Console.WriteLine(" ");
                            Console.WriteLine("  We hope this response was relevant, please free to ask more questions.  ");
                        }

                    }
                }

            // then display a message if the user enters an irrelevant topic or question    
            }

             else
            {
                Console.WriteLine("Please search something related to cyber security, as that is what we spcecialise in.");


            }
            do
            {
                Console.WriteLine(" ");
                Console.WriteLine("  Type 'exit' to stop the program.");
                Console.WriteLine("  Press any other key to continue...");

                user_name = Console.ReadLine()?.ToLower(); // Read input and convert to lowercase

            } while (user_name != "exit"); // Continue until user enters "exit"

            Console.WriteLine("Program exited. Goodbye!");
        }
    }
    }
