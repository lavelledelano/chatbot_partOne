﻿namespace part1_attempt_4
{
    public class design_prompt
    {
        public design_prompt()
        {
        }
    }
}